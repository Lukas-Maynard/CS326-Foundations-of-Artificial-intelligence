package solutions;

public class TicTacToePlayer {
    //while we have not reached a terminal state:
         //print the current board
         //let the human player input (row, column)
        //run the minimax search to find the best move
    //announce the winner or draw
}
