package search_solutions;

import core_search.BaseSearch;
import core_search.Node;
import core_search.SortedQueue;
import search_problems.SlidingTilePuzzle;

import java.util.Comparator;
import java.util.List;

/**
 * Solving the Sliding Tile Puzzle using greedy best-first search with the "sum of distances" heuristic
 */
public class SlidingTileGBFSDistanceSum extends BaseSearch<List<Integer>, String> {

    public SlidingTileGBFSDistanceSum() {
<<<<<<< HEAD
        super(new SlidingTilePuzzle(), new SortedQueue<>(new CompareSumOfDistances(new SlidingTilePuzzle())));
=======
        super(new SlidingTilePuzzle(),
                new SortedQueue<>(new CompareSumOfDistances(new SlidingTilePuzzle())));
>>>>>>> 2c401bc2f546b941c010c2607a791a8b7c4e5a8a
    }

    public static void main(String[] args) {
        SlidingTileGBFSDistanceSum solver = new SlidingTileGBFSDistanceSum();
        solver.search();
    }

    public static class CompareSumOfDistances implements Comparator<Node<List<Integer>, String>> {

        private final SlidingTilePuzzle problem;

        public CompareSumOfDistances(SlidingTilePuzzle problem) {
<<<<<<< HEAD
            System.out.println("COMPARESUM OF DISTANCES");      // DEBUG
=======
>>>>>>> 2c401bc2f546b941c010c2607a791a8b7c4e5a8a
            this.problem = problem;
        }

        @Override
        public int compare(Node<List<Integer>, String> o1, Node<List<Integer>, String> o2) {
<<<<<<< HEAD
            System.out.println("COMPARE FUNC");     // DEBUG
=======
>>>>>>> 2c401bc2f546b941c010c2607a791a8b7c4e5a8a
            if (sumOfDistancesHeuristic(o1.getState()) < sumOfDistancesHeuristic(o2.getState())) {
                return -1;
            } else if (sumOfDistancesHeuristic(o1.getState()) == sumOfDistancesHeuristic(o2.getState())) {
                return 0;
            } else {
                return 1;
            }
        }

        private int sumOfDistancesHeuristic(List<Integer> state) {
            return problem.sumOfDistances(state);
        }
    }
}