package problems;

import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.move.Move;

import java.awt.*;
import java.util.List;

public interface Chess {
//    Color Player = new Color[]{Color.WHITE, Color.BLACK};

    List<Move> actions(Board board);
    int utility(Board board);
    boolean isTerminal(Board board);
    void initializeBoard(Board board);
    Board execute(Move move, Board board);
    void undo(Move move, Board board);
}
